package buildcraft.core.internal;

public interface ICustomLEDBlock {
	String[] getLEDSuffixes();
}
