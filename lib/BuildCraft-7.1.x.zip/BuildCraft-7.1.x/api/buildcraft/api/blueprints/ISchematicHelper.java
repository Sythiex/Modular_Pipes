package buildcraft.api.blueprints;

import net.minecraft.item.ItemStack;

public interface ISchematicHelper {
	boolean isEqualItem(ItemStack a, ItemStack b);
}
