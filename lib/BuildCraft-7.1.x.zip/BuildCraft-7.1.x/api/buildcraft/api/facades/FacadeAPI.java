package buildcraft.api.facades;

public final class FacadeAPI {
	public static IFacadeItem facadeItem;

	private FacadeAPI() {

	}
}
